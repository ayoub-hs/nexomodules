<?php

namespace Modules\NsContainerManagement;

use App\Services\Module;

class NsContainerManagementModule extends Module
{
    public function __construct()
    {
        parent::__construct(__FILE__);
    }
}
