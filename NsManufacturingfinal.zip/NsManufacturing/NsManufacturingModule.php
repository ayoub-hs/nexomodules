<?php

namespace Modules\NsManufacturing;

use App\Services\Module;

class NsManufacturingModule extends Module
{
    public function __construct()
    {
        parent::__construct( __FILE__ );
    }
}
